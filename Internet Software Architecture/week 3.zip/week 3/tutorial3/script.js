// console.log("Hello Javascript")
// // qno:1 Print your name and interest to the console using consle.loh()
// console.log("Aadarsha K.C. nothing")
// // qno:2 differene between let, const, and var ? provide example

// for(var i=0; i<5; i++){
//     let j=6;   //scoped block varaible 
//     var k=7 //global block variable
//     // it prints the j cause its in block {}
//     console.log(j);
// }
// // it gives refrence error because its out the block/ {} so 
// // let is the block scoped variable.
// // console.log(j)
// // it will print the k cause its a global scoped variable 
// console.log(k);
// k=10 ;
// // so now k will be 10 cause var can be modified and changed.
// console.log(k);
// // let is also modified and changed but it should be in same block
// j=15
// console.log(j);
// // now lets see the const which is scoped block variable and 
// // cannot be changed or modified
// // const name=Herald
// // name=othercollege
// // console.log(name) //so it shows error cause its not modified or changaabke


// // naming variable

// // Herald College Kathmandu

// let heraldCollegeKathmadu = "Naxal" //camel case(recommended)
// let HeraldCollegeKathmandu = "Naxal" //pascal case (not recommended)
// let herald_college_kathmandu = "Naxal" //snake case 
// console.log()
// //Qno: 3 

// let a = 10;
// if (a>5){
//     a=20;
// }
// else{
//     a=30;
// }
// console.log(a);

// // Qno:4
 
// let num = parseFloat(prompt("Enter a number: "))

// if(num>0){
//     console.log("Positive number");
// }
// else if(num<0){
//     console.log("Negative number");
// }
// else{
//     console.log("neither Negative nor positive");
// }
// // Qno:5

// for(let i=1; i<101; i++){
//     if(i%3===0 && i%5===0){
//         console.log("FizzBuzz");
//     }
//     else if(i%5==0){
//         console.log("Buzz");
//     }
//     else if(i%3===0){
//         console.log("Fizz");
//     }
//     else {
//         console.log(i);
//     }
// }

// //Qno:5

// let num1 = parseFloat(prompt("Enter a number: "));
// let num2 = parseFloat(prompt("Enter another number: "));
// const operator = prompt('Enter operator (+,-,*,/)');
// switch(operator){
//     case "+": answer = num1 + num2;
//     break;
//     case "-":answer = num1 - num2 ;
//     break;
//     case "*":answer = num1 * num2;
//     break;
//     case"/":answer = num1 / num2;

// console.log(answer);

// Qno6 

// for(let i=11; i<20; i++){
//     console.log(i);
// }

// //Qno7 

// for(let i=10; i>0; i--){
//     console.log(i);
// }

// let i=10;

// while(i>1){
// console.log(i)
// i--;
// }

// //Qno8 
// let j=0
// do {
//     console.log("hello, world!")
//     j ++;
// }
// while(j>1)

//QNO:9

// let firstarr=[1, 2, 3, 4, 5, 6,];
// let sum=0;

// for(let i = 0;i<firstarr.length ; i++){
//     sum= sum + firstarr[i]
// }
// console.log(sum);

//Qno10

// let arr1= [1,2,3,4,5]
// console.log(arr1)
// arr1.pop();
// console.log(arr1)

// arr1.push(21);
// console.log(arr1)

// let person = [name: 'John', age: 30]
// for (let x in person){
//     console.log(x);
//     console.log(person(x));
// }
// console.log(person.name +"" + person["age"]);

// function oddEvenChecker(num){
//     if(num%2==0){
//         return "Even number";
//     }else{
//         return "Odd number"
//     }
// }