// QNo: 1
//     let num = parseFloat(prompt("Enter a number: "));
//     function oddEvenChecker(num){
//     if(num%2==0 && num>0){
//         return num+" "+"is Even & positive number";
//     } else {
//         return "It's either negative or odd number";
//     }
// }
//     console.log(oddEvenChecker(num))

    // //Qno:2 
    // let number = parseFloat(prompt("Enter a number: "));
    // function printArray(number) {
    //     var newArray = [];

    //     for (var i=1; i<= number; i++) {
    //         newArray.push(i);
    //     }
    // return newArray;
    // }
    // console.log(printArray(number))

    // // Qno:3
    // function countTrue(arr){
    //     let count = 0;
    //     for(let i=0;i<arr.length;i++){
    //         if(arr[i]===true){
    //             count++;  
    //         }
    //     }
    //     return count;
    //   }
    //   console.log(countTrue([true, false, false,true, false]))

    //Qno:4 

      // function giveMeSomething(a){
      //   return "something"+" "+a
      // }
      // console.log(giveMeSomething("is better than nothing"))

      //QNo:5
      // function checkDivisible(n){
      //   if(n % 4 === 0 && n % 6 === 0 && n % 8 !== 0){
      //     return n+" "+"is divisible by 4 and 6 but not by 8.";
      //    } else {
      //     return n+" "+"doesnot satisfy the condition.";
      //    }
      // }
      // let n=parseInt(prompt("Enter a number: "));
      
      // console.log(checkDivisible(n));

      //Qno:6
    // function numberChecker(n){
    //   if(n>0){
    //     return n+" "+"is the positive number";
    //   } else {
    //     return n+" "+"is the negative number";
    //   }
    // }
    // let n=parseInt(prompt("Enter a number: "));
    // console.log(numberChecker(n))

    // //Qno:7
    //  function getVoteCount(a){
    //   return a.upvotes-a.downvotes;
    //   }
    //   console.log(getVoteCount({upvotes:2, downvotes: 33}));

  //   //QNO:8 
//     class Person {
//       constructor(name, age) {
//           this.name = name;
//           this.age = age;
//       }
  
//       compareAge(otherPerson) {
//           if (this.age < otherPerson.age) {
//               return otherPerson.name+" "+"is older than me.";
//           } else if (this.age > otherPerson.age) {
//               return otherPerson.name+" "+"is younger than me.";
//           } else {
//               return otherPerson.name+" "+"is the same age as me.";
//           }
//       }
//   }
//   const p1 = new Person("Samuel", 24);
//   const p2 = new Person("Joel", 36);
//   const p3 = new Person("Lily", 24);
  
//   console.log(p1.compareAge(p2)); 
//   console.log(p2.compareAge(p1));  
//   console.log(p1.compareAge(p3)); 

  //Qno9
  
  function getTotalPrice(groceries) {
    let total = 0;
    groceries.forEach(grocery => {
      total += grocery.quantity * grocery.price;
    });
    return Math.round(total * 100) / 100;
  }
  console.log(getTotalPrice([ 
    { product: "Milk", quantity: 1, price: 1.50 }
  ]));
  
  console.log(getTotalPrice([ 
    { product: "Milk", quantity: 1, price: 1.50 }, 
    { product: "Cereals", quantity: 1, price: 2.50 }
  ])); 
  
  console.log(getTotalPrice([ 
    { product: "Milk", quantity: 3, price: 1.50 }
  ])); 
  
  console.log(getTotalPrice([ 
    { product: "Milk", quantity: 1, price: 1.50 }, 
    { product: "Eggs", quantity: 12, price: 0.10 }, 
    { product: "Bread", quantity: 2, price: 1.60 }, 
    { product: "Cheese", quantity: 1, price: 4.50 }
  ])); 
  
  console.log(getTotalPrice([ 
    { product: "Chocolate", quantity: 1, price: 0.10 }, 
    { product: "Lollipop", quantity: 1, price: 0.20 }
  ])); 
  