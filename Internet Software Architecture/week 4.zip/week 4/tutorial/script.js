// // QNO1

// let arr = [1,2,3,4,5,6,7,8,9,10];
// //  for method 
// for(let i=0; i<arr.length; i++){
//     console.log(arr[i]);
// }

// // forEach method 
// arr.forEach(function(val){
//     console.log(val);
// })

// // map method 
// arr.map(function(currentValue){
//     console.log(currentValue)
// })

// QNO:2

// let Prices=[2400,3400,3500,4300,1900,2900,3100];
// let taxRate = 0.15;
// let updated_Price=[];

//for method
// for( i=0; i<Prices.length; i++){
//     let updatedPrice= Prices[i]+Prices[i]*taxRate;
//     updated_Price.push(updatedPrice);
// }
// console.log(updated_Price);

// QNO:3
//map method
// let newArray = Prices.map(function(currentValue){
//     return currentValue+currentValue*taxRate;
// })
//     console.log(newArray);

// QNO:4

// let books=[{titile:"The great Gatsby", rating:4.2}, {title:"To kill a mocking bord", rating:4.5},{title:"Brave new world", rating:3.8},{title:"1984", rating:4.9},{title:"In search of lost time", rating:4.2},]
// let newBooks=[];

// for method 

// for(i=0; i<books.length; i++){
//     if(books[i].rating>=4){
//         newBooks.push(books[i]);
//     }
// }
// console.log(newBooks);

// // QNO5 

// let new_book= books.filter(function(currentValue){
//     return currentValue.rating>=4;
// })
// console.log(new_book);

//QNo: 6

// let expenses=[10000, 50000, 7050, 2500, 3200, 5200, 1849];
// let totalExpenses=0;

// for method
// for(i=0; i<expenses.length; i++){
//     totalExpenses= expenses[i]+totalExpenses;
// }
// console.log(totalExpenses);

//QNo:7 

// Reduce method 
// let total_Expenses = expenses.reduce(function(total, currentValue){
//     return total+currentValue;
// })
//     console.log(total_Expenses);

// QNO:8

// function printHello(){
//     console.log("Hello world");
// }
// printHello();

// let printHello= () => console.log ("Hello World")
// printHello()

// QNO:9
 
// let addNumbers = (a,b) => a + b;
// console.log(addNumbers(2,3))

//QNO: 10

//Immediately Invoked Function Expression
//  QNO:11
// (function(num){
//     let factorial = 1;
//     for(let i= 1; i<= num; i++){
//         factorial= factorial* i
//      }
//     console.log(factorial)
// }
// )(5)

// QNO:12

// let companies = [
//     {name:"company one", category:"Finance", start:1981, end:2003},
//     {name:"comapany two", category:"Retail", start:1982, end:2008},
//     {name:"comapany three", category:"Auto", start:1999, end:2007},
//     {name:"company four", category:"Retail", start:2001, end:2009},
//     {name:"company five", category:"Technology", start:1995, end:2010},
//     {name:"company six", category:"Finance", start:2006, end:2012},
// ];

// for (let i=0; i<companies.length; i++){
//     let company = companies[i];
//     if(company.end-company.start>=10){
//         console.log(companies[i].name)
//     }
// }

