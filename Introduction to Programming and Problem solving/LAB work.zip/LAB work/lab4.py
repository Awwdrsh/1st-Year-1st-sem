#QNO:1
"""
num=10
even_sum = 0
odd_sum = 0
for i in range(num):
    if i % 2 == 0:
        even_sum += i
    else:
        odd_sum += i
print("Sum of even numbers in the range 10:", even_sum)
print("Sum of odd numbers in the range 10:",odd_sum)
"""

#Qno:2
"""
positive_count = 0
negative_count = 0
positive_sum = 0
while True:
    try:
        user_input = input("Enter a number (or 'done' to finish): ")
        if user_input.lower() == 'done':
            break
        number = int(user_input)
        if number > 0:
            positive_count += 1
            positive_sum += number
        elif number < 0:
            negative_count += 1
    except ValueError:
        print("Invalid input! Please enter a valid integer or 'done' to finish.")
        continue
print("Number of positive integers entered:", positive_count)
print("Number of negative integers entered:", negative_count)
print("Sum of positive numbers:", positive_sum)
"""
#QNO:3
"""
for number in range(7):
    if number == 3 or number == 6:
        continue
    print(number)
"""

#QNO:4 
name = input("Enter your name: ")
age = int(input("Enter your age: "))
qualification = input("Enter your qualification: ")
contact_number = input("Enter your contact number: ")
address = input("Enter your address: ")
email = input("Enter your email: ")
interested_area = input("Enter the area you are interested in: ")
description = input("Enter a brief description about yourself: ")

salary_expectations = int(input("Enter your salary expectations: "))

experience_years = int(input("Enter your years of experience: "))

if salary_expectations > 20000:
    if experience_years >= 2:
        print("You are shortlisted. Your enquiry has been recorded. We will notify you, thank you!!")
    else:
        print("Your work experience must be at least 2 years.")
else:
    print("Your enquiry has been recorded. We will notify you, thank you!!")
























