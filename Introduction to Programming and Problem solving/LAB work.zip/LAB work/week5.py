"""QNO:1
# Define two dictionaries
dict1 = {"a": 1, "b": 2}
dict2 = {"c": 3, "d": 4}
# Merge dictionaries
merged_dict = {**dict1, **dict2}
# Print the result
print(merged_dict)
"""
"""
# Nested list of cars
cars = [
    ["Toyota", "2021-05-10", 25000],
    ["Honda", "2020-11-15", 22000],
    ["Ford", "2022-03-08", 28000],
    ["Tesla", "2023-01-20", 45000],
    ["BMW", "2019-07-18", 35000]
]
# Print the list
for car in cars:
    print(f"Manufacturer: {car[0]}, Make Date: {car[1]}, Price: ${car[2]}")
"""

"""
# Create two tuples
tuple1 = (1, 2, 3, 4, 5)
tuple2 = ("apple", "banana", "cherry", "date")

# Reverse the tuples
reversed_tuple1 = tuple1[::-1]
reversed_tuple2 = tuple2[::-1]

# Display before and after reversing
print("Original tuple1:", tuple1)
print("Reversed tuple1:", reversed_tuple1)

print("Original tuple2:", tuple2)
print("Reversed tuple2:", reversed_tuple2)

# Find the index of an item in a tuple
item_to_find = "cherry"
index_in_tuple2 = tuple2.index(item_to_find)

# Display the index
print(f"Index of '{item_to_find}' in tuple2:", index_in_tuple2)
"""

"""
# Dictionary with string items
string_dict = {"name": "Alice", "city": "Wonderland", "profession": "Explorer"}
print("String dictionary items:")
for key in string_dict:
    print(f"{key}: {string_dict[key]}")

# Dictionary with integer items
int_dict = {"a": 10, "b": 20, "c": 30, "d": 40}
total_sum = sum(int_dict.values())

print("\nInteger dictionary items:", int_dict)
print("Sum of all integer values:", total_sum)
"""

# Define two sets of fruits
fruits_set1 = {"apple", "banana", "cherry", "date"}
fruits_set2 = {"banana", "cherry", "elderberry", "fig"}

# Find the union of the two sets
union_set = fruits_set1 | fruits_set2

# Find the intersection of the two sets
intersection_set = fruits_set1 & fruits_set2

# Find the difference between the two sets
difference_set1 = fruits_set1 - fruits_set2
difference_set2 = fruits_set2 - fruits_set1

# Display the results
print("Union of sets:", union_set)
print("Intersection of sets:", intersection_set)
print("Difference between set1 and set2:", difference_set1)
print("Difference between set2 and set1:", difference_set2)
























