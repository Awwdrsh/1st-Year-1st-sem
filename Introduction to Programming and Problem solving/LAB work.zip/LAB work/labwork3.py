"""#labreport:3 Qno1
#take input from the users(unit of electricity consumed)
unit=float(input("Enter unit of electricity consumed:"))
#check the unit consumed and compare if it is 100 or less and  run statement and print output
if unit<=100:
    bill_float=unit*0
    print("There is no charge upto 100unit so your bill amount is", bill_float)
#check the unit consumed and if condition meets minus 100 and calculate the remaining unit cost 
elif unit>100 and unit<200:
        unit=unit-100
        bill_float=unit*5
        print("The electricity consumed is more than 100 unit so it will 5rs per unit so your bill is", bill_float)
#check the unit and minus 200 from unit consumed and calculate the remaining cost @ 10rs and add cost of 100unit@5
else:
        unit=unit-200
        bill_float=100*5
        totalAmount_float=(unit*10)+bill_float
        print("Your electricity consumed is more than 200 so after 200unit you will be charged 10per unit so you bill is", totalAmount_float)
"""
"""#QNO:2
#take input from the user(A,B or C)
word=input("Enter word (A,B or C) :")
#check user input using if /elif condition and display output
if word=="A":
        print(word, "is for Apple")
elif word=="B":
        print(word, "is for Banana")
elif word=="C":
        print(word, "is for Coconut")
else:
        print("Provided user input/word is not 'A', 'B' or 'C'.")
"""
"""
#QNO:3
#take the input from the user
num=int(input("Enter a number:"))
#compare num if it is divisible by 5 or not
if num%5==0:
        print("He/llo")
else:
        print("Bye")
    """
"""#QNO:4
#ask user their ageby user input
age=int(input("Enter your age: "))
#compare if they are less than 18 or not
if age>=18:
    print("You are eligible for citizenship")
else:
    print("You are too young for citizenship")
"""

"""#QNO:5
#Ask user their age by user input
age=int(input("Enter your age: "))
#compare or check if they are senior citizens or not
if age >=70:
    print("You are senior citizen")
else:
    print("You arenot senior citizen")
   """     



        
        
