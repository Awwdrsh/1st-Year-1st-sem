"""Questions of Lab report:2
2. Print first and last name in reverse order with a space between them.
3. Write a python program to find the sum and product of two numbers.
4. Write a python program to print the area of circle. Take radius of circle as an input form the user
"""
"""Qno: 2
#take input and store it into firstname and lastname variable.
firstname=input("Enter your first name here: ")
lastname=input("Enter your last name here: ")
#Display variable lastname first and put some spaces in between and display firstname variable
print(lastname, "\t", firstname )"""

"""QNO: 3
#taking input from the users
num1=int(input("Enter first number: "))
num2=int(input("Enter second number: "))
#finding out the sum and product of two number and storing in different varaible
sum_int=num1+num2
product_int=num1*num2
#displaying output by printing variables that we stored value after calculation/operations
print("the sum of two given numbers is", sum_int, "\nThe product of two given number is ", product_int)
"""

"""QNO: 4 
#taking the radius as a input from the user
radius=int(input("Enter the radius of the circle: "))
#using formula for area of circle and storing in area varaible
area_float=(radius**2)*22/7
#displaying the answer stored in area variable.
print("The area of circle is ",area_float, "sq. unit")"""
 

