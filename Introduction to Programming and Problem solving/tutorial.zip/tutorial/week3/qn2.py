"""num1=int(input("Enter:"))
num2=int(input("Enter:"))
num3=int(input("Enter:"))
sum = num1 + num2 + num3
if num1==num2 or num2==num1 or num1==num3:
    sum=0
    print(sum)
else:
    print(sum)"""

#qno3
city=input("enter your city:").lower()
if city=="kathmandu"
    print ("Pashupati nath")
elif city=="pokhara" 
    print ("Fewa lake")
elif city=="nepalgunj"
    print ("Bagheshwori temple")
elif city=="Birgunj" 
    print ("Ghanta ghar birgunj")
else:
    print ("error:Invalid destination")

