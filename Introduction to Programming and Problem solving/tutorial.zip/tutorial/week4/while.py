"""#Qno1
i=1
while i<=100:
    if i%2==1:
         print(i)
    i+=1"""

    
"""age=int(input("Enter your age:"))
while age:
    if age>0:
        print("valid age")
    else:
        print ("Invalid age")
        age=int(input("Enter your age:"))"""
        
    




"""enter=(input("Enter what you want to do 'Print paycheck'/ 'change benefit'/'Exit':")).lower()
while enter !="":
    if enter=="print paycheck":
        print("Here is your paycheck")
    elif enter== "change benefit":
        print("Here is your benefit")
    elif enter== "exit":
        print("You are exited")
    else:
        print("Out of ocntext option")
    enter=(input("Enter what you want to do 'Print paycheck'/ 'change benefit'/'Exit':")).lower()
"""

"""i = int(input("Enter an integer: "))
while i > 0:
    i = int(input("Enter an integer: "))
print("You entered loop stoping integer: {i}")"""

    


    
