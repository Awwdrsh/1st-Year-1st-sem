#For you1
"""
menu = ["momo", "pizza"]

print("Menu:", menu)

menu.append("fries")
print("new menu:", menu)

menu.insert(2,"sanwich")
print("new menu:", menu)

extra= ["kfc", "hotwings"]
new=menu+extra
print("new menu", new)

new[0]="C.momo"
print("new menu:", new)

del new[0]
print("new menu:", new)

new.remove("pizza")
print("new menu:", new)

new.sort()
print(new)

for i in range(len(new)):
    print(new[i])

"""
#FOR YOU 2
#QNO1
"""
list=(1,2,3,4,5,6,7,8,9,10)
four=list[3]
last=list[-1]
print("4th element:", four)
print("last element:", last)
"""

#QNO2
"""
list=[1,2,3,4,1,1,1,1,1]
numbercount=list.count(1)
print("number appeared:" ,numbercount)
"""

#QNO3
"""
list=[1,2,3,4]
greatestnum= max(list)
print(greatestnum)
"""

#QNO4
"""
list=[-3,-2,-1,0,1,2,3]
positive_numbers = [ ]
negative_numbers = [ ]
for i in list:
    if i > 0:
        positive_numbers.append(i)  
    elif i < 0:
        negative_numbers.append(i)
print(positive_numbers)
print(negative_numbers)
"""
#FOR YOU EXERCISE
#QNO1
movies=[["ab","bc","cd"],[1999,2000,2001]]
for i in movies:
    print(movies(i,i))


















