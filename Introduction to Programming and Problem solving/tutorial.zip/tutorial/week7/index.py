f= open('text.txt','r')
file_content = f.read()
print(file_content)
f.close()
