import random
import os.path
import json
random.seed()

def draw_board(board):
    # develop code to draw the board
    print("  0 1 2")
    for i, row in enumerate(board):
        print(i, "|".join(row))
        if i < 2:
            print("  -----")
    pass

def welcome(board):
    # prints the welcome message
    # display the board by calling draw_board(board)
    print("Welcome to Noughts and Crosses!")
    draw_board(board)
    pass

def initialise_board(board):
    # develop code to set all elements of the board to one space ' '
    return [[" " for _ in range(3)] for _ in range(3)]
    return board
    
def get_player_move(board):
    # develop code to ask the user for the cell to put the X in,
    # and return row and col
    while True:
        try:
            row, col = map(int, input("Enter your move as row and column (e.g., 0 1): ").split())
            if board[row][col] == " ":
                return row, col
            else:
                print("That cell is already taken. Try again.")
        except (ValueError, IndexError):
            print("Invalid input. Enter two numbers between 0 and 2.")
    return row, col

def choose_computer_move(board):
    # develop code to let the computer chose a cell to put a nought in
    # and return row and col
    """Chooses a random available cell for the computer's move."""
    empty_cells = [(r, c) for r in range(3) for c in range(3) if board[r][c] == " "]
    return random.choice(empty_cells)
    return row, col


def check_for_win(board, mark):
    # develop code to check if either the player or the computer has won
    # return True if someone won, False otherwise
    """Checks if the given mark (X or O) has won the game."""
    for row in board:
        if all(cell == mark for cell in row):
            return True
    
    for col in range(3):
        if all(board[row][col] == mark for row in range(3)):
            return True
    
    if all(board[i][i] == mark for i in range(3)) or all(board[i][2-i] == mark for i in range(3)):
        return True
    
    return False

def check_for_draw(board):
    # develop cope to check if all cells are occupied
    # return True if it is, False otherwise
    for row in board:
        for cell in row:
            if cell == " ":
                return False  # Return False if any cell is empty
    return True

def play_game(board):
    # develop code to play the game
    # star with a call to the initialise_board(board) function to set
    # the board cells to all single spaces ' '
    board = initialise_board()
    # then draw the board
    draw_board(board) 
    # then in a loop, get the player move, update and draw the board
    # check if the player has won by calling check_for_win(board, mark),
    while True:
        # Player move
        row, col = get_player_move(board)
        board[row][col] = "X"
        draw_board(board)
    # if so, return 1 for the score
    if check_for_win(board, "X"):
            print("Congratulations! You win!")
            return 1  
    # if not check for a draw by calling check_for_draw(board)
    # if drawn, return 0 for the score
    if check_for_draw(board):
            print("It's a draw!")
            return 0
    # if not, then call choose_computer_move(board)
    # to choose a move for the computer
    # update and draw the board
    # check if the computer has won by calling check_for_win(board, mark),
    row, col = choose_computer_move(board)
    board[row][col] = "O"
    print("Computer placed an 'O':")
    draw_board(board)
    # if so, return -1 for the score
    if check_for_win(board, "O"):
            print("Computer wins!")
            return -1 
    # if not check for a draw by calling check_for_draw(board)
    # if drawn, return 0 for the score
    if check_for_draw(board):
            print("It's a draw!")
            return 0
    #repeat the loop
    return 0
                    
                
def menu():
    print("\nMenu:")
    # 1 - Play the game
    print("1 - Play the game")
    # 2 - Save score in file 'leaderboard.txt'
    print("2 - Save score")
    # 3 - Load and display the scores from the 'leaderboard.txt'
    print("3 - Load and display scores")
     # q - End the program
    print("q - Quit")
    # get user input of either '1', '2', '3' or 'q'
    choice = input("Enter your choice: ").strip().lower()
    while choice not in ["1", "2", "3", "q"]:
        choice = input("Invalid choice! Enter 1, 2, 3, or q: ").strip().lower()
    return choice

def load_scores():
    # develop code to load the leaderboard scores
    # from the file 'leaderboard.txt'
    # return the scores in a Python dictionary
    if not os.path.exists("leaderboard.txt"):
        return {}
    # with the player names as key and the scores as values
    with open("leaderboard.txt", "r") as file:
        try:
            return json.load(file)
        except json.JSONDecodeError:
            return {}
    # return the dictionary in leaders
    return leaders
    
def save_score(score):
    # develop code to ask the player for their name
    name = input("Enter your name: ").strip()
    # and then save the current score to the file 'leaderboard.txt'
    scores = load_scores()
    
    scores[name] = scores.get(name, 0) + score

    with open("leaderboard.txt", "w") as file:
        json.dump(scores, file)
    
    print("Score saved successfully!")
    return


def display_leaderboard(leaders):
    # develop code to display the leaderboard scores
    print("\nLeaderboard:")
    if not leaders:
        print("No scores yet.")
        return
    # passed in the Python dictionary parameter leader
    for name, score in sorted(leaders.items(), key=lambda x: x[1], reverse=True):
        print(f"{name}: {score}")
    pass

