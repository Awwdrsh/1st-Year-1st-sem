import os

# Welcome() function prints the welcome message.
def welcome():
    print("Welcome to the Caesar Cipher")
    print("This program encrypts and decrypts text using Caesar Cipher.")

# Checks if the given file exists.
def is_file(filename):
    return os.path.isfile(filename)

# Encrypts a message using the Caesar Cipher.
def encrypt(message, shift):
    encrypted_message = ""
    for char in message:
        if char.isalpha():
            encrypted_message += chr((ord(char) - 65 + shift) % 26 + 65)
        else:
            encrypted_message += char
    return encrypted_message

# Decrypts a message using the Caesar Cipher.
def decrypt(message, shift):
    return encrypt(message, -shift)

# Reads messages from a file, processes them (encrypt or decrypt), and returns a list of processed messages.
def process_file(filename, mode, shift):
    messages = []
    with open(filename, 'r') as file:
        for line in file:
            line = line.strip().upper()
            if mode == 'e':
                messages.append(encrypt(line, shift))
            elif mode == 'd':
                messages.append(decrypt(line, shift))
    return messages

# Writes a list of messages to a file.
def write_messages(messages):
    with open('results.txt', 'w') as file:
        for message in messages:
            file.write(message + '\n')

# Prompts the user to choose between console or file input for processing messages.
def message_or_file():
    """
    Prompts the user to choose between console or file input for processing messages.
    Returns the mode, message (or None), and filename (or None).
    """
    while True:
        mode = input("Would you like to encrypt (e) or decrypt (d)? ").strip().lower()
        if mode in ('e', 'd'):
            break
        print("Invalid mode. Please enter 'e' for encrypt or 'd' for decrypt.")
    
    while True:
        input_method = input("Would you like to read from a file (f) or the console (c)? ").strip().lower()
        if input_method in ('f', 'c'):
            break
        print("Invalid input method. Please enter 'f' for file or 'c' for console.")
    
    if input_method == 'f':
        while True:
            filename = input("Enter a filename: ").strip()
            if not is_file(filename):
                print(f"The file '{filename}' does not exist. Creating a new file...")
                with open(filename, 'w') as file:
                    print(f"The file '{filename}' has been created.")
                    word = input("Enter a word or message to add to the file: ").strip().upper()
                    file.write(word + "\n")
                    print(f"The word '{word}' has been written to '{filename}'.")
            else:
                print(f"\nContent of the file '{filename}':")
                with open(filename, 'r') as file:
                    for line in file:
                        print(line.strip())
            break
        return mode, None, filename
    else:
        message = input("What message would you like to process? ").strip().upper()
        return mode, message, None

# Handles the output choice and displays or writes the results.
def handle_output(messages):
    """
    Handles the output of processed messages.
    Asks the user whether to display in the console or write to a file.
    """
    while True:
        output_method = input("Would you like the output in the console (c) or a file (f)? ").strip().lower()
        if output_method in ('c', 'f'):
            break
        print("Invalid choice. Please enter 'c' for console or 'f' for file.")
    
    if output_method == 'c':
        print("\nProcessed Messages:")
        for message in messages:
            print(message)
    else:
        write_messages(messages)
        print("Output written to results.txt")
        print("Opening 'results.txt'...")
        os.system('notepad results.txt' if os.name == 'nt' else 'open results.txt')

# The main function for running the Caesar Cipher program.
def main():
    """
    The main function for running the Caesar Cipher program.
    """
    welcome()
    while True:
        mode, message, filename = message_or_file()
        
        while True:
            try:
                shift = int(input("What is the shift number (0-25)? "))
                if 0 <= shift <= 25:
                    break
                else:
                    print("Invalid shift. Please enter a number between 0 and 25.")
            except ValueError:
                print("Invalid shift. Please enter a valid integer.")
        
        if filename:
            # File processing
            processed_messages = process_file(filename, mode, shift)
        else:
            # Console input processing
            processed_messages = [encrypt(message, shift) if mode == 'e' else decrypt(message, shift)]
        
        handle_output(processed_messages)
        
        while True:
            repeat = input("Would you like to process another message? (y/n): ").strip().lower()
            if repeat in ('y', 'n'):
                break
            print("Invalid response. Please enter 'y' for yes or 'n' for no.")
        
        if repeat == 'n':
            print("Thanks for using the program, goodbye!")
            break

if __name__ == "__main__":
    main()
